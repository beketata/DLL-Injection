#pragma once

#include "pch.h"

#define BUF_SIZE 64

__interface IAdder
{
//	void Add();
};

class Adder // : public IAdder
{
	IAdder* pVftable;

	HWND _hRes;
	HWND _hAdd1;
	HWND _hAdd2;

public:

	Adder( HWND hDlg );

	// __interface IAdder
	//
	void Add();
};
