#include "pch.h"


INT_PTR CALLBACK DialogProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
#if !defined(_WIN64)

	_patch->Unpatch( 0x4012D0 );

	auto res = ( ( INT_PTR( CALLBACK* )( HWND, UINT, WPARAM, LPARAM ) )A( 0x4012D0 ) )( hDlg, uMsg, wParam, lParam );

	if( uMsg == WM_INITDIALOG )
	{
		::SetWindowText( hDlg, "Simple Calc" );
	}
	else
	{
		_patch->Patch( 0x4012D0 );
	}

	return res;
}
PATCH( 0x4012D0, DialogProc )

#else

	_patch->Unpatch( 0x140001390 );

	auto res = ( ( INT_PTR( CALLBACK* )( HWND, UINT, WPARAM, LPARAM ) )A( 0x140001390 ) )( hDlg, uMsg, wParam, lParam );

	if( uMsg == WM_INITDIALOG )
	{
		::SetWindowText( hDlg, "Simple Calc" );
	}
	else
	{
		_patch->Patch( 0x140001390 );
	}

	return res;
}
PATCH( 0x140001390, DialogProc )

#endif
