#include "pch.h"


#if !defined(_WIN64)
	PATCH( 0x4011C0, Adder::Add )
#else
	PATCH( 0x140001250, Adder::Add )
#endif
void Adder::Add()
{
#if !defined(_WIN64)
	char* pBuf = (char*)( ( void* ( __cdecl* )( size_t ) )A( 0x40193D ) )( BUF_SIZE ); // operator new[]
#else
	char* pBuf = (char*)( ( void* ( __cdecl* )( size_t ) )A( 0x140001B68 ) )( BUF_SIZE ); // operator new[]
#endif

	::GetWindowText( _hAdd1, pBuf, BUF_SIZE );
	auto add1 = atol( pBuf );

	::GetWindowText( _hAdd2, pBuf, BUF_SIZE );
	auto add2 = atol( pBuf );

	// ���������� "���".
	//
	auto res = add1 + add2;

	sprintf_s( pBuf, BUF_SIZE, "%ld", res );
	::SetWindowText( _hRes, pBuf );

	CStringA str;
	str.Format( "%ld + %ld = %ld", add1, add2, res );
	LogLine( str.GetString() );

	// ����� ������: DeleteBuf( pBuf ) �� ��� ������
	//
#if !defined(_WIN64)
	( ( void( __thiscall* )( Adder*, void* ) )A( 0x401280 ) )( this, pBuf );
#else
	( ( void( __thiscall* )( Adder*, void* ) )A( 0x140001330 ) )( this, pBuf );
#endif
	}
