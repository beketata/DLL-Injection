#include "pch.h"


#if !defined(_WIN64)
	VAR( g_hMulRes, HWND, 0x41B36C )
#else
	VAR( g_hMul1, HWND, 0x140021CF0 )
	VAR( g_hMul2, HWND, 0x140021CF8 )
	VAR( g_hMulRes, HWND, 0x140021CE0 )
#endif


#if !defined(_WIN64)

void __stdcall Mult_( HWND hMul1, HWND hMul2 )
{
	char buf[BUF_SIZE];

	::GetWindowText( hMul1, buf, BUF_SIZE );
	auto mul1 = atol( buf );

	::GetWindowText( hMul2, buf, BUF_SIZE );
	auto mul2 = atol( buf );

	// ���������� "���".
	//
	auto res = mul1 * mul2;

	sprintf_s( buf, BUF_SIZE, "%ld", res );

	::SetWindowText( g_hMulRes->var, buf );
}

// void __usercall Mult( HWND hMul1@<eax>, HWND hMul2@<ebx> )
__declspec( naked )
void Mult()
{
	__asm
	{
		push	ebx
		push	eax
		call	Mult_

		ret
	}
}
PATCH( 0x401150, Mult )

#else

void Mult()
{
	char buf[64];

	GetWindowTextA( g_hMul1->var, buf, sizeof( buf ) );
	auto mul1 = atol( buf );

	GetWindowTextA( g_hMul2->var, buf, sizeof( buf ) );
	auto mul2 = atol( buf );

	// ���������� "���".
	//
	auto res = mul1 * mul2;

	sprintf_s( buf, sizeof( buf ), "%ld", res );

	SetWindowTextA( g_hMulRes->var, buf );

	CStringA str;
	str.Format( "%ld * %ld = %ld", mul1, mul2, res );
	LogLine( str.GetString() );
}
PATCH( 0x140001100, Mult )

#endif

