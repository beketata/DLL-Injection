//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SimpleCalc.rc
//
#define IDD_DIALOG1                     101
#define IDC_ADD_EDIT1                   1001
#define IDC_ADD_EDIT2                   1002
#define IDC_ADD_RES                     1003
#define IDC_ADD_BUTTON                  1004
#define IDC_MUL_EDIT1                   1005
#define IDC_MUL_EDIT2                   1006
#define IDC_MUL_RES                     1007
#define IDC_MUL_BUTTON                  1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
