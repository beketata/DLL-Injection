#include <Windows.h>
#include <cstdio>
#include <CommCtrl.h>

/* usually, the resource editor creates this file to us: */
#include "resource.h"

#pragma comment(lib, "ComCtl32.lib")

#define BUF_SIZE 64

class Adder* _pAdder;

long g_add1 = LONG_MIN;
long g_add2 = LONG_MIN;

long g_mul1 = LONG_MIN;
long g_mul2 = LONG_MIN;

HWND g_hMul1;
HWND g_hMul2;
HWND g_hMulRes;


#if !defined(_WIN64)

void __stdcall Mult_( HWND hMul1, HWND hMul2 )
{
	char buf[BUF_SIZE];

	::GetWindowText( hMul1, buf, BUF_SIZE );
	auto mul1 = atol( buf );

	::GetWindowText( hMul2, buf, BUF_SIZE );
	auto mul2 = atol( buf );

	sprintf_s( buf, BUF_SIZE, "%ld", ( mul1 == 2 && mul2 == 2 ) ? ( 5 ) : ( mul1 * mul2 ) );
	::SetWindowText( g_hMulRes, buf );
}

// void __usercall Mult( HWND hMul1@<eax>, HWND hMul2@<ebx> )
__declspec( naked )
void Mult()
{
	__asm
	{
		push	ebx
		push	eax

		call	Mult_

		ret
	}
}

#else

void Mult()
{
	char buf[BUF_SIZE];

	::GetWindowText( g_hMul1, buf, BUF_SIZE );
	auto mul1 = atol( buf );

	::GetWindowText( g_hMul2, buf, BUF_SIZE );
	auto mul2 = atol( buf );

	sprintf_s( buf, BUF_SIZE, "%ld", ( mul1 == 2 && mul2 == 2 ) ? ( 5 ) : ( mul1 * mul2 ) );
	::SetWindowText( g_hMulRes, buf );
}

#endif


__interface IAdder
{
	void Add();
};

class Adder : public IAdder
{
	HWND _hRes;
	HWND _hAdd1;
	HWND _hAdd2;

public:

	Adder( HWND hDlg )
	{
		_hAdd1 = ::GetDlgItem( hDlg, IDC_ADD_EDIT1 );
		_hAdd2 = ::GetDlgItem( hDlg, IDC_ADD_EDIT2 );
		_hRes = ::GetDlgItem( hDlg, IDC_ADD_RES );
	}

	void IAdder::Add()
	{
		// ������������ ��������� ������ ��� ������������ ������������� ������� ���������� ������� � DLL.
		//
		char* pBuf = new char[BUF_SIZE];

		::GetWindowText( _hAdd1, pBuf, BUF_SIZE );
		auto add1 = atol( pBuf );

		::GetWindowText( _hAdd2, pBuf, BUF_SIZE );
		auto add2 = atol( pBuf );

		sprintf_s( pBuf, BUF_SIZE, "%ld", ( add1 == 2 && add2 == 2 )?( 5 ):( add1 + add2 ) );
		::SetWindowText( _hRes, pBuf );

		// ������������ ������������ ������ � ������ ������.
		//
		DeleteBuf( pBuf );
	}

	void DeleteBuf( void* pBuf )
	{
		if( pBuf )
		{
			delete[] pBuf;
			pBuf = nullptr;
		}
	}

};


INT_PTR CALLBACK DialogProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	char* pend;
	char buf[BUF_SIZE];

	switch( uMsg )
	{
		case WM_INITDIALOG:
		{
			_pAdder = new Adder( hDlg );

			auto edit1 = ::GetDlgItem( hDlg, IDC_ADD_EDIT1 );
			auto edit2 = ::GetDlgItem( hDlg, IDC_ADD_EDIT2 );

			SendMessage( edit1, EM_SETLIMITTEXT, 5, 0 );
			SendMessage( edit2, EM_SETLIMITTEXT, 5, 0 );

			g_hMul1 = ::GetDlgItem( hDlg, IDC_MUL_EDIT1 );
			g_hMul2 = ::GetDlgItem( hDlg, IDC_MUL_EDIT2 );
			g_hMulRes = ::GetDlgItem( hDlg, IDC_MUL_RES );

			SendMessage( g_hMul1, EM_SETLIMITTEXT, 5, 0 );
			SendMessage( g_hMul2, EM_SETLIMITTEXT, 5, 0 );

			return TRUE;
		}
		break;

		case WM_COMMAND:
		{
			switch( LOWORD( wParam ) )
			{
				case IDCANCEL:
				{
					SendMessage( hDlg, WM_CLOSE, 0, 0 );
				}
				return TRUE;

				// ������� �� ������ "=" � ���������� ����.
				//
				case IDC_ADD_BUTTON:
				{
					_pAdder->Add();
				}
				return TRUE;

				// ������� �� ������ "*" � ���������� ����.
				//
				case IDC_MUL_BUTTON:
				{
#if !defined(_WIN64)
					__asm
					{
						mov		eax, g_hMul1
						mov		ebx, g_hMul2

						call	Mult
					}
#else
					Mult();
#endif
				}
				return TRUE;

				case IDC_ADD_EDIT1:
				case IDC_ADD_EDIT2:
				{
					auto res = ::GetDlgItem( hDlg, IDC_ADD_RES );

					auto btn = ::GetDlgItem( hDlg, IDC_ADD_BUTTON );

					auto edit1 = ::GetDlgItem( hDlg, IDC_ADD_EDIT1 );
					::GetWindowText( edit1, buf, BUF_SIZE );
					errno = 0;
					auto add1 = strtol( buf, &pend, 10 );
					if( errno != 0 || *pend != '\0' || buf[0] == '\0' )
					{
						::EnableWindow( btn, FALSE );
						::SetWindowText( res, "" );
					}
					else
					{
						auto edit2 = ::GetDlgItem( hDlg, IDC_ADD_EDIT2 );
						::GetWindowText( edit2, buf, BUF_SIZE );
						errno = 0;
						auto add2 = strtol( buf, &pend, 10 );
						if( errno != 0 || *pend != '\0' || buf[0] == '\0' )
						{
							::EnableWindow( btn, FALSE );
							::SetWindowText( res, "" );
						}
						else
						{
							::EnableWindow( btn, TRUE );

							if( add1 != g_add1 || add2 != g_add2 )
							{
								::SetWindowText( res, "" );
								g_add1 = add1;
								g_add2 = add2;
							}
						}
					}
				}
				return TRUE;

				case IDC_MUL_EDIT1:
				case IDC_MUL_EDIT2:
				{
					auto res = ::GetDlgItem( hDlg, IDC_MUL_RES );

					auto btn = ::GetDlgItem( hDlg, IDC_MUL_BUTTON );

					auto edit1 = ::GetDlgItem( hDlg, IDC_MUL_EDIT1 );
					::GetWindowText( edit1, buf, BUF_SIZE );
					errno = 0;
					auto mul1 = strtol( buf, &pend, 10 );
					if( errno != 0 || *pend != '\0' || buf[0] == '\0' )
					{
						::EnableWindow( btn, FALSE );
						::SetWindowText( res, "" );
					}
					else
					{
						auto edit2 = ::GetDlgItem( hDlg, IDC_MUL_EDIT2 );
						::GetWindowText( edit2, buf, BUF_SIZE );
						errno = 0;
						auto mul2 = strtol( buf, &pend, 10 );
						if( errno != 0 || *pend != '\0' || buf[0] == '\0' )
						{
							::EnableWindow( btn, FALSE );
							::SetWindowText( res, "" );
						}
						else
						{
							::EnableWindow( btn, TRUE );

							if( mul1 != g_mul1 || mul2 != g_mul2 )
							{
								::SetWindowText( res, "" );
								g_mul1 = mul1;
								g_mul2 = mul2;
							}
						}
					}
				}
				return TRUE;
			}
		}
		break;

		case WM_CLOSE:
		//if( MessageBox( hDlg, TEXT( "Close the program?" ), TEXT( "Close" ), MB_ICONQUESTION | MB_YESNO ) == IDYES )
		{
			DestroyWindow( hDlg );
		}
		return TRUE;

		case WM_DESTROY:
		{
			PostQuitMessage( 0 );
		}
		return TRUE;
	}

	return FALSE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	HWND hDlg;
	MSG msg;
	BOOL ret;

	InitCommonControls();
	hDlg = CreateDialogParam( hInstance, MAKEINTRESOURCE( IDD_DIALOG1 ), 0, DialogProc, 0 );
	ShowWindow( hDlg, nCmdShow );

	while( (ret = GetMessage( &msg, 0, 0, 0 )) != 0 )
	{
		if( ret == -1 )
			return -1;

		if( !IsDialogMessage( hDlg, &msg ) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
	}

	return 0;
}
